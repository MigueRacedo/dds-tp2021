package ar.edu.utn.frba.dds.dominio.Criterios;

import ar.edu.utn.frba.dds.dominio.Rescate.Hogar;
import ar.edu.utn.frba.dds.dominio.Rescate.TipoAnimalesPermitidos;

public class CriterioAceptaGatos implements Criterio {

  @Override
  public boolean cumple(Hogar hogar) {
    return hogar.getTipoAnimalesPermitidos().equals(TipoAnimalesPermitidos.AMBOS) || hogar.getTipoAnimalesPermitidos().equals(TipoAnimalesPermitidos.GATO);
  }

}
