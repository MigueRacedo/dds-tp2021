package ar.edu.utn.frba.dds.dominio.MascotaYDuenio;

public enum TipoCaracteristica {
	ES_BOOLEANA,
	CON_VALORES
}
