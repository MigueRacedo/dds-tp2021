package ar.edu.utn.frba.dds.dominio.Excepciones;

public class ContraseniaDebilException extends RuntimeException{

  public ContraseniaDebilException(String message) {
    super(message);
  }
}