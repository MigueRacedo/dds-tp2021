package ar.edu.utn.frba.dds.dominio.Rescate;

public enum TipoAnimalesPermitidos {
  GATO,
  PERRO,
  AMBOS
}
