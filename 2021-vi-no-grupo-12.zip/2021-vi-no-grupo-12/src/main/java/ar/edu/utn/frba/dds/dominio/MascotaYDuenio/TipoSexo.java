package ar.edu.utn.frba.dds.dominio.MascotaYDuenio;

public enum TipoSexo {
  MACHO, HEMBRA, NOSESABE
}
