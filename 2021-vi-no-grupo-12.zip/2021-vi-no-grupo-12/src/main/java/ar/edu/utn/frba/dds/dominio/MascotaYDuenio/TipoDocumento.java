package ar.edu.utn.frba.dds.dominio.MascotaYDuenio;

public enum TipoDocumento {
	DNI, PASAPORTE, RUC
}
